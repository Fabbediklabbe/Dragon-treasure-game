import classes.Dragon_treasure;

public class Main {

	public static void main(String[] args) {
		Dragon_treasure dragontreasure = new Dragon_treasure();
		dragontreasure.setupGame();
	}
}
